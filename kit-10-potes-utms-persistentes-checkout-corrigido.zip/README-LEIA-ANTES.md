# Página de produto Magalu

## Como abrir

Abra `index-magalu-tempalte.html` no navegador ou publique esta pasta em uma hospedagem estática.

## Estrutura enviada

- `index-magalu-tempalte.html` — página principal do produto.
- `css/` — estilos da página.
- `js/` — scripts da página, carrossel, header e Meta Pixel.
- `images/` — imagens do produto, loja e avaliações.
- `api/` — rota opcional para Facebook CAPI em deploy serverless/Vercel.
- `docs/` — guias rápidos de Pixel/CAPI e organização.

## Produto exportado

- Nome: Kit 10 Potes Herméticos De Vidro Para Marmita 640ml
- Preço: R$19,90

## Meta Pixel / CAPI

O Pixel ID público fica em `js/facebook-pixel-config.js`.
O token CAPI **não** fica em nenhum arquivo público. Configure o token como variável de ambiente no servidor/Vercel.
