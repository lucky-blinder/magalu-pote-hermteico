/* ================================================================
   VERCEL SERVERLESS — FACEBOOK CONVERSIONS API (CAPI)
   Arquivo: api/facebook-capi.js

   Variáveis obrigatórias na Vercel:
   - FACEBOOK_PIXEL_ID
   - FACEBOOK_CAPI_TOKEN

   Variável opcional para teste no Events Manager:
   - FACEBOOK_TEST_EVENT_CODE
   ================================================================ */

function responder(res, status, dados) {
  res.statusCode = status;
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.end(JSON.stringify(dados));
}

function pegarIp(req) {
  const forwarded = req.headers["x-forwarded-for"];
  if (typeof forwarded === "string" && forwarded.length) {
    return forwarded.split(",")[0].trim();
  }
  return req.socket && req.socket.remoteAddress;
}

function normalizarCustomData(customData) {
  const dados = customData && typeof customData === "object" ? customData : {};
  return {
    currency: dados.currency || "BRL",
    value: typeof dados.value === "number" ? dados.value : Number(dados.value || 0) || 0,
    content_name: dados.content_name || "Kit 10 Potes Herméticos De Vidro Para Marmita 640ml",
    content_type: dados.content_type || "product"
  };
}

module.exports = async function handler(req, res) {
  if (req.method === "OPTIONS") return responder(res, 200, { ok: true });

  if (req.method !== "POST") {
    return responder(res, 405, { ok: false, erro: "Use POST." });
  }

  const pixelId = process.env.FACEBOOK_PIXEL_ID;
  const token = process.env.FACEBOOK_CAPI_TOKEN;
  const testEventCode = process.env.FACEBOOK_TEST_EVENT_CODE;

  if (!pixelId || !token) {
    return responder(res, 500, {
      ok: false,
      erro: "Configure FACEBOOK_PIXEL_ID e FACEBOOK_CAPI_TOKEN nas variáveis de ambiente da Vercel."
    });
  }

  try {
    const body = typeof req.body === "string" ? JSON.parse(req.body || "{}") : (req.body || {});
    const userData = body.user_data && typeof body.user_data === "object" ? body.user_data : {};

    const evento = {
      event_name: body.event_name || "PageView",
      event_time: Math.floor(Date.now() / 1000),
      event_id: body.event_id,
      event_source_url: body.event_source_url || req.headers.referer,
      action_source: "website",
      user_data: {
        client_ip_address: pegarIp(req),
        client_user_agent: req.headers["user-agent"],
        fbp: userData.fbp,
        fbc: userData.fbc
      },
      custom_data: normalizarCustomData(body.custom_data)
    };

    const payload = { data: [evento] };
    if (testEventCode) payload.test_event_code = testEventCode;

    const url = `https://graph.facebook.com/v20.0/${pixelId}/events?access_token=${encodeURIComponent(token)}`;
    const resposta = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    const texto = await resposta.text();
    let respostaMeta;
    try { respostaMeta = JSON.parse(texto); } catch (_) { respostaMeta = texto; }

    return responder(res, resposta.ok ? 200 : 502, {
      ok: resposta.ok,
      status_meta: resposta.status,
      resposta_meta: respostaMeta
    });
  } catch (erro) {
    return responder(res, 500, { ok: false, erro: erro.message });
  }
};
