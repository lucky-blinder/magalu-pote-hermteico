# Dashboard local — editar produto sem mexer no HTML

Este dashboard foi criado para você editar a página `index-magalu-tempalte.html` de forma simples, visual e profissional.

## Como abrir

Na pasta do projeto, execute:

```bash
python editor_dashboard.py
```

Depois abra no navegador:

```txt
http://127.0.0.1:8788/dashboard/
```

Preview da página gerada:

```txt
http://127.0.0.1:8788/index-magalu-tempalte.html
```

## O que dá para editar

### Produto

- Nome do produto
- Link do checkout
- Preço antigo/riscado
- Preço atual

### Fotos

- Adicionar/remover fotos do carrossel
- Escolher imagens do computador
- Alterar manualmente o caminho das imagens
- Definir quantas fotos o produto terá

As imagens enviadas pelo dashboard vão para a pasta:

```txt
images/
```

### Descrição

- Parágrafos da descrição
- Características principais
- Ficha técnica

### Avaliações

- Nome do cliente
- Estrelas
- Texto do depoimento
- Tempo da avaliação
- Foto da avaliação
- Duplicar/remover avaliações

### Loja

- Nome da loja
- Texto abaixo da loja
- Logo da loja

## Como salvar ou gerar uma página nova em ZIP

### Opção recomendada: gerar ZIP novo

Depois de editar, clique em:

```txt
Gerar ZIP novo
```

O dashboard vai criar um pacote completo em:

```txt
exports/
```

Esse ZIP contém a nova página do produto pronta para publicar, incluindo:

- `index-magalu-tempalte.html`
- `css/`
- `js/`
- `images/`
- `api/` para CAPI na Vercel
- `docs/`

Essa opção **não precisa editar a página atual** para você ter o pacote novo.

### Opção alternativa: salvar no HTML atual

Se quiser aplicar as alterações direto no arquivo aberto do projeto, clique em:

```txt
Salvar e gerar HTML
```

O dashboard vai:

1. salvar os dados em `data/produto-dashboard.json`
2. fazer backup do HTML anterior em `backups-dashboard/`
3. atualizar `index-magalu-tempalte.html`

## Arquivos criados

```txt
editor_dashboard.py
dashboard/index.html
dashboard/dashboard.css
dashboard/dashboard.js
data/produto-dashboard.json
backups-dashboard/    # criada automaticamente ao salvar
```

## Segurança

Esse dashboard é para uso local. Não publique o dashboard aberto em produção.

Para subir na Vercel, suba a página gerada (`index-magalu-tempalte.html`) e os arquivos necessários do site. O dashboard é uma ferramenta de edição local.
