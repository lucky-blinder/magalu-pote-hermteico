# Configurar Facebook Pixel + CAPI na Vercel

Este projeto já está preparado para disparar eventos pelo **Pixel do navegador** e pela **Conversions API (CAPI)** quando hospedado na Vercel.

## 1. Colocar o Pixel ID no arquivo do site

Abra:

`js/facebook-pixel-config.js`

Troque:

```js
pixelId: "COLE_SEU_PIXEL_ID_AQUI"
```

pelo seu Pixel ID real.

Exemplo:

```js
pixelId: "123456789012345"
```

## 2. Configurar variáveis de ambiente na Vercel

No painel da Vercel:

1. Abra o projeto.
2. Vá em **Settings**.
3. Vá em **Environment Variables**.
4. Crie estas variáveis:

```txt
FACEBOOK_PIXEL_ID=SEU_PIXEL_ID_AQUI
FACEBOOK_CAPI_TOKEN=SEU_TOKEN_CAPI_AQUI
```

Opcional para teste no Gerenciador de Eventos da Meta:

```txt
FACEBOOK_TEST_EVENT_CODE=SEU_CODIGO_DE_TESTE_AQUI
```

Depois clique em **Save**.

## 3. Fazer novo deploy

Depois de criar/alterar variáveis de ambiente, faça um novo deploy na Vercel.

Você pode fazer isso com:

- novo commit/push no GitHub conectado à Vercel; ou
- botão **Redeploy** no painel da Vercel.

## 4. Eventos configurados

O site dispara automaticamente:

- `PageView` ao carregar a página.
- `ViewContent` ao carregar o produto.
- `InitiateCheckout` ao clicar em botão/link de compra.

## 5. Deduplicação Pixel + CAPI

O projeto gera um `event_id` para cada evento.

O mesmo `event_id` é enviado para:

- Pixel do navegador.
- CAPI via `/api/facebook-capi`.

Isso permite que a Meta deduplique os eventos corretamente.

## 6. Arquivos importantes

- `js/facebook-pixel-config.js` — configura Pixel ID e eventos.
- `js/facebook-pixel.js` — dispara eventos no navegador.
- `js/facebook-capi-client.js` — envia os mesmos eventos para `/api/facebook-capi`.
- `api/facebook-capi.js` — rota serverless da Vercel que usa o token CAPI com segurança.

## 7. Segurança

Nunca coloque o `FACEBOOK_CAPI_TOKEN` dentro de HTML ou JS público.

O token deve ficar somente nas variáveis de ambiente da Vercel.
