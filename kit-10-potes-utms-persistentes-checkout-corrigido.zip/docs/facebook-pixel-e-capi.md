# Facebook Pixel e CAPI — Guia rápido PT-BR

## Configurar pelo dashboard

Abra o dashboard local:

`http://127.0.0.1:8788/dashboard/`

Entre na aba **Meta Pixel/CAPI**, preencha:

- Pixel ID da Meta
- Token CAPI da Meta
- Código de evento de teste, se quiser testar no Events Manager

Clique em **Salvar e gerar HTML**. O dashboard atualiza `js/facebook-pixel-config.js` e salva o token localmente em `data/facebook-meta.local.json` para você copiar para as variáveis de ambiente da Vercel/servidor.

> O token CAPI não é colocado no HTML público.

## Pixel do Facebook

Arquivo para editar:

`js/facebook-pixel-config.js`

Troque:

```js
pixelId: "COLE_SEU_PIXEL_ID_AQUI"
```

pelo ID real do seu Pixel. Depois recarregue o site.

O HTML já carrega estes arquivos:

```html
<script src="js/facebook-pixel-config.js" defer></script>
<script src="js/facebook-pixel.js" defer></script>
<script src="js/facebook-capi-client.js" defer></script>
```

Enquanto o ID estiver como placeholder, o Pixel do navegador não envia eventos.

## CAPI / Conversions API na Vercel

A integração de produção fica em:

`api/facebook-capi.js`

Na Vercel, configure as variáveis de ambiente:

```txt
FACEBOOK_PIXEL_ID=SEU_PIXEL_ID_AQUI
FACEBOOK_CAPI_TOKEN=SEU_TOKEN_CAPI_AQUI
```

Opcional para teste:

```txt
FACEBOOK_TEST_EVENT_CODE=SEU_CODIGO_DE_TESTE_AQUI
```

Depois faça novo deploy.

## Eventos automáticos

O projeto já dispara:

- `PageView`
- `ViewContent`
- `InitiateCheckout` ao clicar no botão/link de compra

Cada evento usa o mesmo `event_id` no Pixel do navegador e na CAPI para deduplicação na Meta.

## Segurança

Nunca coloque o token CAPI dentro do HTML ou JS público do site.
O token deve ficar somente em variável de ambiente da Vercel.

## Passo a passo completo

Veja:

`docs/configurar-facebook-capi-vercel.md`
