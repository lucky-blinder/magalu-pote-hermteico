# Guia rápido — editar produto, imagens, título, descrição e avaliações

Arquivo principal do site:

`index-magalu-tempalte.html`

Pasta das imagens:

`images/`

> Dica: coloque suas novas imagens dentro da pasta `images/` e use caminhos assim: `images/nome-da-imagem.webp`.

---

## 1. Imagens principais do produto / carrossel

No arquivo `index-magalu-tempalte.html`, procure por:

```js
// CARROSSEL DE FOTOS DO PRODUTO
```

Fica dentro do bloco:

```js
window.PRODUTO = {
```

Trecho atual:

```js
images: [
  // Foto 1 — imagem principal que aparece primeiro
  "images/kit-10-potes-hermeticos-vidro-640ml-1.webp",

  // Foto 2 — troque este caminho quando tiver a segunda foto
  "images/kit-10-potes-hermeticos-vidro-640ml-1.webp",

  // Foto 3 — troque este caminho quando tiver a terceira foto
  "images/kit-10-potes-hermeticos-vidro-640ml-1.webp",

  // Foto 4 — troque este caminho quando tiver a quarta foto
  "images/kit-10-potes-hermeticos-vidro-640ml-1.webp",

  // Foto 5 — troque este caminho quando tiver a quinta foto
  "images/kit-10-potes-hermeticos-vidro-640ml-1.webp"
],
```

Para trocar, altere somente o caminho dentro das aspas.

Exemplo:

```js
// Foto 2 — troque este caminho quando tiver a segunda foto
"images/produto-foto-2.webp",
```

Se quiser adicionar mais fotos, adicione mais uma linha antes do fechamento `],`:

```js
// Foto 6
"images/produto-foto-6.webp"
```

Se não for a última linha, coloque vírgula no final.

---

## 2. Título do produto

### Título visível na página

Procure no HTML por:

```html
<h1 class="text-lg font-normal leading-snug text-foreground mb-5">
```

Trecho atual:

```html
<h1 class="text-lg font-normal leading-snug text-foreground mb-5">Kit 10 Potes Herméticos De Vidro Para Marmita 640ml</h1>
```

Troque apenas o texto entre `>` e `</h1>`.

Exemplo:

```html
<h1 class="text-lg font-normal leading-snug text-foreground mb-5">Novo Nome Do Produto Aqui</h1>
```

### Título da aba do navegador

No começo do HTML, procure:

```html
<title>
```

Troque o texto do produto também.

### Nome dentro da ficha técnica

Procure por:

```html
<span class="text-muted-foreground">Nome</span>
```

Na mesma linha, altere o texto do produto dentro do segundo `<span>`.

---

## 3. Preço do produto

Procure por:

```html
<!-- PREÇO -->
```

Ou procure diretamente por:

```html
R$ 67,90
```

Preço antigo/riscado:

```html
<p class="text-sm text-muted-foreground line-through">R$ 67,90</p>
```

Preço atual é separado em partes:

```html
<span class="text-sm text-foreground">R$</span><span class="text-3xl font-bold text-foreground">27</span><span class="text-lg text-foreground">,90</span>
```

Para mudar para `R$ 49,90`, altere assim:

```html
<span class="text-sm text-foreground">R$</span><span class="text-3xl font-bold text-foreground">49</span><span class="text-lg text-foreground">,90</span>
```

### Preço fixo no rodapé

Procure por:

```html
BARRA FIXA DE COMPRA
```

Também atualize o preço nessa área para ficar igual ao preço principal.

---

## 4. Link do checkout / compra

Procure por:

```js
checkout:
```

Dentro de:

```js
window.PRODUTO = {
```

Trecho atual:

```js
checkout: "https://pag.ambientevirtual.es/checkout/kit-10-potes-hermeticos-de-vidro-para-ma",
```

Troque pelo novo link do checkout.

Também existe um link fallback no botão principal. Procure por:

```html
id="prod-buy-main"
```

E troque o `href="..."` se necessário.

---

## 5. Descrição do produto

Procure por:

```html
Descrição e ficha técnica
```

Logo abaixo ficam os parágrafos principais:

```html
<p class="text-sm text-foreground leading-relaxed mb-3"><strong>Item:</strong> Kit 10 Potes Herméticos De Vidro Para Marmita 640ml. Produto original, com garantia e nota fiscal.</p>
<p class="text-sm text-foreground leading-relaxed mb-3">Kit composto por 10 potes retangulares de vidro borossilicato, cada um com capacidade de 640ml e tampa com vedação hermética.</p>
<p class="text-sm text-foreground leading-relaxed mb-4">Não retém odores ou manchas e pode ser utilizado no freezer, forno e micro-ondas sem a tampa, além de ser compatível com lava-louças.</p>
```

Troque somente os textos dentro dos `<p>`.

---

## 6. Características principais

Na mesma seção de descrição, procure por:

```html
Características principais
```

Cada característica segue este modelo:

```html
<div class="flex items-start gap-2"><span class="text-[#00a650] font-bold">✓</span><p class="text-sm text-foreground"><strong>Kit completo:</strong> 10 potes de 640ml</p></div>
```

Para editar:

- Troque o texto dentro de `<strong>...</strong>` para o nome da característica.
- Troque o texto depois do `</strong>` para a descrição.

Exemplo:

```html
<strong>Material:</strong> aço inox resistente
```

---

## 7. Ficha técnica completa

Procure por:

```html
id="prod-specs"
```

Itens principais:

```html
<span class="text-muted-foreground">Nome</span><span class="text-foreground font-medium text-right">Kit 10 Potes Herméticos De Vidro Para Marmita 640ml</span>
<span class="text-muted-foreground">Marca</span><span class="text-foreground font-medium">Bumper</span>
<span class="text-muted-foreground">Material</span><span class="text-foreground font-medium">Vidro borossilicato</span>
<span class="text-muted-foreground">Garantia</span><span class="text-foreground font-medium">3 meses</span>
```

Para adicionar uma nova linha, copie uma linha de ficha técnica e altere os dois textos.

---

## 8. Avaliações dos clientes

Procure por:

```html
AVALIAÇÕES DOS CLIENTES — EDIÇÃO MANUAL
```

Cada avaliação fica dentro de um bloco:

```html
<article> ... </article>
```

Modelo simplificado:

```html
<article class="border-b border-gray-200 pb-4">
  <div class="flex items-center justify-between gap-3 mb-2">
    <p class="font-medium text-foreground">Nome do Cliente</p>
    <span class="text-amber-400 text-sm">★★★★★</span>
  </div>
  <p class="text-sm text-foreground mb-1">Comentário do cliente aqui.</p>
  <p class="text-xs text-muted-foreground">há 1 semana</p>
  <div class="flex gap-2 mt-2">
    <button type="button" onclick="prodOpenPhoto('images/foto-avaliacao.webp')" class="block">
      <img src="images/foto-avaliacao.webp" alt="Foto da avaliação" loading="lazy" class="rounded-lg object-cover" style="width:155px;height:155px">
    </button>
  </div>
</article>
```

### O que alterar em cada avaliação

- Nome:

```html
<p class="font-medium text-foreground">Maria L.</p>
```

- Estrelas:

```html
<span class="text-amber-400 text-sm">★★★★☆</span>
```

Exemplos:

```html
★★★★★
★★★★☆
★★★☆☆
```

- Comentário:

```html
<p class="text-sm text-foreground mb-1">Não usei ainda, mas parecem ser resistentes.</p>
```

- Tempo:

```html
<p class="text-xs text-muted-foreground">há 1 semana</p>
```

- Foto da avaliação:

Altere nos dois lugares:

```html
onclick="prodOpenPhoto('images/potes-avaliacao-2.webp')"
```

E:

```html
src="images/potes-avaliacao-2.webp"
```

Os dois caminhos devem ser iguais.

---

## 9. Fotos das avaliações

Coloque as imagens novas na pasta:

`images/`

Depois altere cada avaliação para apontar para a imagem nova.

Exemplo:

```html
onclick="prodOpenPhoto('images/avaliacao-cliente-4.webp')"
```

```html
src="images/avaliacao-cliente-4.webp"
```

---

## 10. Loja / vendedor

Procure por:

```html
Informações da loja
```

Você pode alterar:

- Logo da loja:

```html
<img src="images/bumper-magazine-store-logo.png" alt="Logo Bumper Magazine"
```

- Nome da loja:

```html
<p class="font-semibold text-foreground">Bumper Oficial</p>
```

- Texto abaixo da loja:

```html
<p class="text-sm text-muted-foreground">Lojista Magalu desde 2016</p>
```

---

## 11. Checklist rápido antes de publicar

Depois de alterar o produto, confira:

- [ ] Todas as imagens novas estão dentro da pasta `images/`.
- [ ] Os caminhos começam com `images/`.
- [ ] O título foi alterado no `<h1>`.
- [ ] O título da aba `<title>` foi alterado.
- [ ] A descrição foi alterada.
- [ ] O preço principal e o preço do rodapé estão iguais.
- [ ] O checkout em `window.PRODUTO.checkout` está correto.
- [ ] As avaliações têm nome, comentário, estrelas, tempo e imagem corretos.
- [ ] As fotos de avaliação têm o mesmo caminho no `onclick` e no `src`.
