# Organização do projeto — Tela_MagaLu_Completa

Esta pasta contém a página, o dashboard local e os exports finais organizados.

# Organização do projeto — PT-BR

## Entrada principal

- `index-magalu-tempalte.html`

## Pastas

- `css/` — estilos do site.
- `js/` — scripts do produto, header e Facebook Pixel opcional.
- `images/` — imagens usadas na página.
- `docs/` — guias de edição manual.
- `dashboard/` — painel local de edição.
- `data/` — dados locais do painel. Não publicar tokens.
- `produtos-criados/` — exports finais gerados sem dashboard.
- `facebook-capi/` — exemplo de backend para CAPI do Facebook.

## Onde editar rápido

### Produto / preço / checkout / galeria

No fim do HTML, procure:

```js
window.PRODUTO = {
```

### Avaliações

No HTML, procure:

```html
AVALIAÇÕES DOS CLIENTES — EDIÇÃO MANUAL
```

Cada avaliação está em um bloco `<article>...</article>`.

### Facebook Pixel

Edite:

`js/facebook-pixel-config.js`

### Facebook CAPI

Use como base:

`facebook-capi/servidor-capi-exemplo-node.js`


## Produtos criados / exportação

Quando clicar em **Gerar ZIP da página** no dashboard, o sistema cria uma nova pasta em:

`produtos-criados/`

Cada produto exportado fica em uma subpasta própria com data e hora, por exemplo:

`produtos-criados/nome-do-produto-20260928-123000/`

Dentro dela ficam:

- `projeto/` — versão extraída completa, pronta para revisar/publicar.
- `nome-do-produto-...zip` — ZIP completo somente da página do produto.

O ZIP não inclui dashboard, `editor_dashboard.py`, pasta `data/`, backups, exports antigos ou token CAPI local. Ele inclui apenas os arquivos necessários para a página funcionar:

- `index-magalu-tempalte.html`
- `css/`
- `js/`
- `images/`
- `api/`
- `docs/`
- `README-LEIA-ANTES.md`
