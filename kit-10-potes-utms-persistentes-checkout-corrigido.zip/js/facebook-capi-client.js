/* ================================================================
   CLIENTE FACEBOOK CAPI — PT-BR
   Este arquivo escuta os eventos do Pixel e chama a rota serverless:
   /api/facebook-capi

   Importante:
   - O token CAPI NÃO fica aqui.
   - O token fica na Vercel em FACEBOOK_CAPI_TOKEN.
   ================================================================ */
(function () {
  "use strict";

  var config = window.FACEBOOK_PIXEL_CONFIG || {};
  var capi = config.capi || {};
  var endpoint = capi.endpoint || "/api/facebook-capi";

  function lerCookie(nome) {
    var match = document.cookie.match(new RegExp("(?:^|; )" + nome.replace(/[.$?*|{}()\[\]\\/+^]/g, "\\$&") + "=([^;]*)"));
    return match ? decodeURIComponent(match[1]) : undefined;
  }

  function deveEnviarCapi() {
    if (!capi.ativo) return false;
    if (location.protocol === "file:") return false;

    // Em preview local com python/http-server não existe rota serverless /api.
    // Na Vercel, a rota api/facebook-capi.js será executada automaticamente.
    if (["localhost", "127.0.0.1"].includes(location.hostname)) return false;

    return true;
  }

  async function enviarParaCapi(detalhes) {
    if (!deveEnviarCapi()) return;

    var payload = {
      event_name: detalhes.event_name,
      event_id: detalhes.event_id,
      event_source_url: detalhes.event_source_url || location.href,
      custom_data: detalhes.custom_data || {},
      user_data: {
        fbp: lerCookie("_fbp"),
        fbc: lerCookie("_fbc")
      }
    };

    try {
      var resposta = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        keepalive: true,
        body: JSON.stringify(payload)
      });

      if (!resposta.ok) {
        console.warn("CAPI não enviado:", resposta.status, await resposta.text());
      }
    } catch (erro) {
      console.warn("Falha ao chamar CAPI:", erro.message);
    }
  }

  window.addEventListener("magaluFacebookEvent", function (evento) {
    enviarParaCapi(evento.detail || {});
  });
})();
