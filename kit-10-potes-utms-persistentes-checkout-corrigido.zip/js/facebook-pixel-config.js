/* ================================================================
   CONFIGURAÇÃO DO FACEBOOK PIXEL — GERADA PELO DASHBOARD
   Edite pelo dashboard em /dashboard/ > aba Meta Pixel/CAPI.

   Segurança:
   - Pixel ID pode ficar no navegador.
   - Token CAPI NÃO fica neste arquivo; fica em data/facebook-meta.local.json
     para uso local e nas variáveis de ambiente do servidor/Vercel.
   ================================================================ */

window.FACEBOOK_PIXEL_CONFIG = {
  "pixelId": "1800974477765426",
  "eventosAutomaticos": {
    "pageView": true,
    "viewContent": true,
    "initiateCheckoutAoClicarComprar": true
  },
  "capi": {
    "ativo": true,
    "endpoint": "/api/facebook-capi"
  },
  "produto": {
    "content_name": "Kit 10 Potes Herméticos De Vidro Para Marmita 640ml",
    "content_type": "product",
    "value": 19.9,
    "currency": "BRL"
  }
};
