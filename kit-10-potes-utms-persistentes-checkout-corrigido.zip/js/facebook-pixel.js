/* ================================================================
   FACEBOOK PIXEL — CÓDIGO ORGANIZADO EM PT-BR
   Edite apenas js/facebook-pixel-config.js com o seu Pixel ID.

   Integração CAPI:
   - Cada evento recebe um eventID.
   - O mesmo eventID é enviado para o Pixel do navegador e para a rota /api/facebook-capi.
   - Isso permite deduplicação correta no Gerenciador de Eventos da Meta.
   ================================================================ */
(function () {
  "use strict";

  var config = window.FACEBOOK_PIXEL_CONFIG || {};
  var pixelId = (config.pixelId || "").trim();
  var pixelNaoConfigurado = !pixelId || pixelId === "COLE_SEU_PIXEL_ID_AQUI";

  function gerarEventId(nomeEvento) {
    return [
      "magalu",
      nomeEvento,
      Date.now(),
      Math.random().toString(16).slice(2)
    ].join("-");
  }

  function avisarCapi(nomeEvento, eventId, dadosEvento) {
    window.dispatchEvent(new CustomEvent("magaluFacebookEvent", {
      detail: {
        event_name: nomeEvento,
        event_id: eventId,
        event_source_url: window.location.href,
        custom_data: dadosEvento || {}
      }
    }));
  }

  function dispararEvento(nomeEvento, dadosEvento) {
    var eventId = gerarEventId(nomeEvento);

    if (!pixelNaoConfigurado && typeof fbq === "function") {
      fbq("track", nomeEvento, dadosEvento || {}, { eventID: eventId });
    }

    avisarCapi(nomeEvento, eventId, dadosEvento || {});
  }

  if (pixelNaoConfigurado) {
    console.info("Facebook Pixel não configurado: preencha o Pixel ID em js/facebook-pixel-config.js");
  } else {
    // Código base oficial do Meta Pixel, mantido em formato simples para edição manual.
    !(function (f, b, e, v, n, t, s) {
      if (f.fbq) return;
      n = f.fbq = function () {
        n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments);
      };
      if (!f._fbq) f._fbq = n;
      n.push = n;
      n.loaded = true;
      n.version = "2.0";
      n.queue = [];
      t = b.createElement(e);
      t.async = true;
      t.src = v;
      s = b.getElementsByTagName(e)[0];
      s.parentNode.insertBefore(t, s);
    })(window, document, "script", "https://connect.facebook.net/en_US/fbevents.js");

    fbq("init", pixelId);
  }

  if (config.eventosAutomaticos && config.eventosAutomaticos.pageView) {
    dispararEvento("PageView", {});
  }

  if (config.eventosAutomaticos && config.eventosAutomaticos.viewContent) {
    dispararEvento("ViewContent", config.produto || {});
  }

  if (config.eventosAutomaticos && config.eventosAutomaticos.initiateCheckoutAoClicarComprar) {
    document.addEventListener("click", function (evento) {
      var botaoComprar = evento.target.closest("#prod-buy, #prod-buy-fixed, a[href*='checkout']");
      if (!botaoComprar) return;
      dispararEvento("InitiateCheckout", config.produto || {});
    });
  }
})();
