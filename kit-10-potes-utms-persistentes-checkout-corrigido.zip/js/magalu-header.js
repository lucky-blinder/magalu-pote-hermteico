(function () {
  "use strict";

  var state = {
    accountOpen: false,
    cepOpen: false,
    cep: "",
    loading: false,
    error: "",
    address: null,
  };

  var ICONS = {
    x: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-x h-5 w-5"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg>',
    user: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-user h-8 w-8 text-[#0086ff]"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>',
    mapPin: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-map-pin h-5 w-5 text-[#0086ff] mt-0.5 flex-shrink-0"><path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"></path><circle cx="12" cy="10" r="3"></circle></svg>',
    truck: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-truck h-5 w-5 text-[#00a650]"><path d="M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2"></path><path d="M15 18H9"></path><path d="M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14"></path><circle cx="17" cy="18" r="2"></circle><circle cx="7" cy="18" r="2"></circle></svg>',
    zap: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-zap h-3 w-3"><path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"></path></svg>',
  };

  function closeAccount() {
    state.accountOpen = false;
    render();
  }

  function closeCep() {
    state.cepOpen = false;
    render();
  }

  function formatCep(value) {
    var digits = value.replace(/\D/g, "").slice(0, 8);
    return digits.length <= 5 ? digits : digits.slice(0, 5) + "-" + digits.slice(5);
  }

  function setCepHeader(address) {
    document.querySelectorAll("header button, [data-magalu-cep-button]").forEach(function (button) {
      if (!button.hasAttribute("data-magalu-cep-button") && !button.querySelector(".lucide-map-pin")) return;
      var span = button.querySelector("[data-magalu-cep-label]") || button.querySelector("span");
      if (span) span.textContent = address.localidade + "/" + address.uf + " - " + address.cep;
      if (!button.querySelector("[data-magalu-full]")) {
        var badge = document.createElement("div");
        badge.setAttribute("data-magalu-full", "true");
        badge.className = "bg-[#00a650] text-white text-[10px] font-bold px-1.5 py-0.5 rounded flex items-center gap-0.5";
        badge.innerHTML = ICONS.zap + "FULL";
        var chevron = button.querySelector(".lucide-chevron-down");
        button.insertBefore(badge, chevron || null);
      }
    });
  }

  function ensureRoot() {
    var root = document.getElementById("magalu-header-modals");
    if (!root) {
      root = document.createElement("div");
      root.id = "magalu-header-modals";
      document.body.appendChild(root);
    }
    return root;
  }

  function accountModal() {
    if (!state.accountOpen) return "";
    return (
      '<div class="fixed inset-0 z-[999] flex items-center justify-center">' +
      '<div class="absolute inset-0 bg-black/50" data-magalu-close-account></div>' +
      '<div class="relative bg-white rounded-lg p-6 mx-4 max-w-sm w-full shadow-xl">' +
      '<button data-magalu-close-account class="absolute top-3 right-3 text-muted-foreground hover:text-foreground">' +
      ICONS.x +
      "</button>" +
      '<div class="text-center">' +
      '<div class="w-16 h-16 bg-[#0086ff]/10 rounded-full flex items-center justify-center mx-auto mb-4">' +
      ICONS.user +
      "</div>" +
      '<h3 class="font-semibold text-foreground text-lg mb-2">Conta</h3>' +
      '<p class="text-sm text-muted-foreground mb-6">Faça login ou crie sua conta na finalização de compra no checkout</p>' +
      '<button data-magalu-close-account class="w-full py-3 bg-[#0086ff] text-white font-semibold rounded-lg">Entendi</button>' +
      "</div></div></div>"
    );
  }

  function cepModal() {
    if (!state.cepOpen) return "";
    var deliveryBrand =
      document.body.getAttribute("data-shop-theme") === "tiktok"
        ? "Entrega garantida pela TikTok Shop"
        : "Entrega garantida pelo Magalu";
    var addr = state.address
      ? '<div class="space-y-4">' +
        '<div class="p-4 bg-muted rounded-lg"><div class="flex items-start gap-3">' +
        ICONS.mapPin +
        '<div><p class="text-sm font-medium text-foreground">' +
        state.address.logradouro +
        '</p><p class="text-sm text-muted-foreground">' +
        state.address.bairro +
        " - " +
        state.address.localidade +
        "/" +
        state.address.uf +
        '</p><p class="text-sm text-muted-foreground">CEP: ' +
        state.address.cep +
        "</p></div></div></div>" +
        '<div class="p-4 bg-[#00a650]/10 border border-[#00a650]/20 rounded-lg">' +
        '<div class="flex items-center gap-2 mb-3"><div class="bg-[#00a650] text-white text-xs font-bold px-2 py-1 rounded flex items-center gap-1">' +
        ICONS.zap +
        'FULL</div><span class="text-sm font-medium text-[#00a650]">Entrega Expressa</span></div>' +
        '<div class="flex items-center gap-3">' +
        ICONS.truck +
        '<div><p class="text-sm font-semibold text-foreground">Receba em 1 a 2 dias úteis</p><p class="text-xs text-muted-foreground">' +
        deliveryBrand +
        '</p></div></div></div>' +
        '<button data-magalu-confirm-cep class="w-full py-3.5 bg-[#00a650] hover:bg-[#009444] text-white font-semibold rounded-lg transition-colors">Confirmar endereço</button></div>'
      : "";

    return (
      '<div class="fixed inset-0 bg-black/50 z-[998] flex items-center justify-center px-4 py-6">' +
      '<div class="bg-white w-full max-w-md rounded-xl max-h-[calc(100vh-3rem)] overflow-auto shadow-xl">' +
      '<div class="flex items-center justify-between p-4 border-b border-gray-200">' +
      '<h2 class="text-lg font-semibold text-foreground">Informe seu CEP</h2>' +
      '<button data-magalu-close-cep class="p-1 hover:bg-muted rounded-full">' +
      ICONS.x +
      "</button></div>" +
      '<div class="p-4 space-y-4">' +
      '<div><label for="magalu-cep" class="block text-sm font-medium text-foreground mb-1.5">CEP</label>' +
      '<div class="flex gap-2"><input id="magalu-cep" type="text" value="' +
      state.cep +
      '" placeholder="00000-000" maxLength="9" class="flex-1 px-4 py-3 border border-gray-200 rounded-lg text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-[#0086ff] bg-background"/>' +
      '<button data-magalu-search-cep class="px-6 py-3 bg-[#0086ff] hover:bg-[#0077e6] disabled:bg-[#0086ff]/50 text-white font-medium rounded-lg transition-colors" ' +
      (state.loading ? "disabled" : "") +
      ">" +
      (state.loading ? "..." : "Buscar") +
      "</button></div>" +
      (state.error ? '<p class="text-sm text-destructive mt-1.5">' + state.error + "</p>" : "") +
      "</div>" +
      addr +
      '<a href="https://buscacepinter.correios.com.br/app/endereco/index.php" target="_blank" rel="noopener noreferrer" class="block text-center text-sm text-[#0086ff] hover:underline">Não sei meu CEP</a>' +
      "</div></div></div>"
    );
  }

  function render() {
    ensureRoot().innerHTML = accountModal() + cepModal();
    var input = document.getElementById("magalu-cep");
    if (input) {
      input.focus();
      input.setSelectionRange(input.value.length, input.value.length);
    }
  }

  function findCepButton(target) {
    var button = target.closest && target.closest("button");
    if (!button) return null;
    if (button.hasAttribute("data-magalu-cep-button")) return button;
    return button.closest("header") && button.querySelector(".lucide-map-pin") ? button : null;
  }

  async function searchCep() {
    var digits = state.cep.replace(/\D/g, "");
    if (digits.length !== 8) {
      state.error = "CEP deve ter 8 dígitos";
      state.address = null;
      render();
      return;
    }
    state.loading = true;
    state.error = "";
    state.address = null;
    render();
    try {
      var response = await fetch("https://viacep.com.br/ws/" + digits + "/json/");
      var data = await response.json();
      if (data.erro) {
        state.error = "CEP não encontrado";
      } else {
        state.address = {
          cep: data.cep,
          logradouro: data.logradouro || "Endereço não especificado",
          bairro: data.bairro || "Bairro não especificado",
          localidade: data.localidade,
          uf: data.uf,
        };
      }
    } catch (e) {
      state.error = "Erro ao buscar CEP. Tente novamente.";
    } finally {
      state.loading = false;
      render();
    }
  }

  function bind() {
    document.addEventListener(
      "click",
      function (event) {
        var account = event.target.closest && event.target.closest('header button[aria-label="Conta"]');
        var cep = findCepButton(event.target);

        if (account || cep) {
          event.preventDefault();
          event.stopPropagation();
          event.stopImmediatePropagation();
        }

        if (account) {
          state.accountOpen = true;
          render();
          return;
        }

        if (cep) {
          state.cepOpen = true;
          state.error = "";
          render();
          return;
        }

        if (event.target.closest && event.target.closest("[data-magalu-close-account]")) {
          closeAccount();
          return;
        }

        if (event.target.closest && event.target.closest("[data-magalu-close-cep]")) {
          closeCep();
          return;
        }

        if (event.target.closest && event.target.closest("[data-magalu-search-cep]")) {
          searchCep();
          return;
        }

        if (event.target.closest && event.target.closest("[data-magalu-confirm-cep]")) {
          if (state.address) setCepHeader(state.address);
          closeCep();
        }
      },
      true
    );

    document.addEventListener("input", function (event) {
      if (event.target && event.target.id === "magalu-cep") {
        state.cep = formatCep(event.target.value);
        event.target.value = state.cep;
        state.error = "";
        state.address = null;
      }
    });

    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape") {
        state.accountOpen = false;
        state.cepOpen = false;
        render();
      }
      if (event.key === "Enter" && event.target && event.target.id === "magalu-cep") {
        event.preventDefault();
        searchCep();
      }
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", bind);
  } else {
    bind();
  }
})();
