/* Produto simples (padrão Polo Wear) — galeria, tamanho, ficha técnica e checkout.
   Configurar via window.PRODUTO = { checkout, images:[...], sizes:[...] } antes de carregar.
   Produtos sem variação de tamanho passam sizes: [] (o seletor não é renderizado). */
(function () {
  "use strict";

  // Recupera UTMs válidas salvas neste domínio.
  var UTM_STORAGE_KEY = "landing_utms_v1";
  var utms = Object.create(null);
  function utmValida(key, value) {
    return /^utm_/i.test(key) && typeof value === "string"
      && value.trim() !== "" && !/\{\{.*?\}\}/.test(value);
  }
  try {
    var savedUtms = JSON.parse(window.localStorage.getItem(UTM_STORAGE_KEY) || "{}");
    Object.keys(savedUtms || {}).forEach(function (key) {
      if (utmValida(key, savedUtms[key])) utms[key] = savedUtms[key];
    });
  } catch (_) {}

  // Captura na entrada; vazios não apagam UTMs anteriores.
  new URLSearchParams(window.location.search).forEach(function (value, key) {
    if (utmValida(key, value)) utms[key] = value;
  });
  try {
    window.localStorage.setItem(UTM_STORAGE_KEY, JSON.stringify(utms));
  } catch (_) {} // Mantém o repasse em memória se o armazenamento estiver bloqueado.

  window.recuperarUTMs = function () {
    return Object.assign({}, utms);
  };

  var cfg = window.PRODUTO || {};
  var CHECKOUT = cfg.checkout || "#";
  var IMAGES = cfg.images && cfg.images.length ? cfg.images : [];
  var SIZES = Array.isArray(cfg.sizes) ? cfg.sizes : ["P", "M", "G", "GG"];
  var VARIANTS = Array.isArray(cfg.variants) ? cfg.variants : null;
  var COLORS = cfg.colors && cfg.colors.length ? cfg.colors : null;
  var QUANTITIES = cfg.quantities && cfg.quantities.length ? cfg.quantities : null;
  var SIZE_LABEL = cfg.sizeLabel || "Tamanho";
  var SIZE_PARAM = SIZE_LABEL.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");

  var selectedSize = 0;
  var selectedColor = 0;
  var selectedQuantity = 0;
  var imageIndex = 0;
  var touchStartX = 0;

  function $(id) {
    return document.getElementById(id);
  }

  function renderGallery() {
    if (imageIndex < 0) imageIndex = IMAGES.length - 1;
    if (imageIndex >= IMAGES.length) imageIndex = 0;
    $("prod-main-image").src = IMAGES[imageIndex];

    var dots = $("prod-dots");
    dots.innerHTML = "";
    IMAGES.forEach(function (_, index) {
      var button = document.createElement("button");
      button.type = "button";
      button.className =
        "w-2 h-2 rounded-full transition-colors " +
        (index === imageIndex ? "bg-[#0086ff]" : "bg-gray-400");
      button.setAttribute("aria-label", "Ver imagem " + (index + 1));
      button.addEventListener("click", function () {
        imageIndex = index;
        renderGallery();
      });
      dots.appendChild(button);
    });
  }

  // PT-BR: avança ou volta uma foto no carrossel, dando a volta no começo/fim.
  function moveGallery(direction) {
    if (!IMAGES.length) return;
    imageIndex += direction;
    renderGallery();
  }

  function renderSizes() {
    var container = $("prod-sizes");
    if (!container || !SIZES.length) return;
    container.innerHTML = "";
    SIZES.forEach(function (size, index) {
      var selected = index === selectedSize;
      var button = document.createElement("button");
      button.type = "button";
      button.className =
        "h-12 rounded-lg border-2 text-base font-semibold transition-colors relative " +
        (selected
          ? "border-[#0086ff] bg-[#0086ff]/5 text-[#0086ff]"
          : "border-gray-300 bg-white text-foreground");
      button.textContent = size;
      if (VARIANTS && VARIANTS[index] && VARIANTS[index].badge) {
        var badge = document.createElement("span");
        badge.textContent = VARIANTS[index].badge;
        badge.style.cssText = "position:absolute;top:-11px;right:-5px;background:#ff0066;color:#fff;border-radius:999px;padding:2px 7px;font-size:10px;line-height:16px;font-weight:700;white-space:nowrap;box-shadow:0 2px 5px rgba(0,0,0,.18)";
        button.appendChild(badge);
      }
      button.setAttribute("aria-label", "Selecionar " + SIZE_LABEL.toLowerCase() + " " + size);
      button.setAttribute("aria-pressed", String(selected));
      button.addEventListener("click", function () {
        selectedSize = index;
        renderSizes();
        updateSelection();
      });
      container.appendChild(button);
    });
  }

  function applySelectionImage() {
    var source = null;
    var quantity = QUANTITIES && QUANTITIES[selectedQuantity];
    if (quantity && Array.isArray(quantity.images)) {
      source = quantity.images[selectedColor] || quantity.images[0];
    } else if (COLORS && COLORS[selectedColor]) {
      source = COLORS[selectedColor].image;
    }
    if (!source) return;
    var foundIndex = IMAGES.indexOf(source);
    if (foundIndex !== -1 && foundIndex !== imageIndex) {
      imageIndex = foundIndex;
      renderGallery();
    }
  }

  function renderColors() {
    var container = $("prod-colors");
    if (!container || !COLORS) return;
    container.innerHTML = "";
    COLORS.forEach(function (color, index) {
      var selected = index === selectedColor;
      var button = document.createElement("button");
      button.type = "button";
      button.className =
        "h-12 rounded-lg border-2 text-base font-semibold transition-colors relative " +
        (selected
          ? "border-[#0086ff] bg-[#0086ff]/5 text-[#0086ff]"
          : "border-gray-300 bg-white text-foreground");
      button.textContent = color.name;
      if (color.badge) {
        var badge = document.createElement("span");
        badge.textContent = color.badge;
        badge.style.cssText = "position:absolute;top:-11px;right:-5px;background:#ff0066;color:#fff;border-radius:999px;padding:2px 7px;font-size:10px;line-height:16px;font-weight:700;white-space:nowrap;box-shadow:0 2px 5px rgba(0,0,0,.18)";
        button.appendChild(badge);
      }
      button.setAttribute("aria-label", "Selecionar cor " + color.name);
      button.setAttribute("aria-pressed", String(selected));
      button.addEventListener("click", function () {
        selectedColor = index;
        applySelectionImage();
        renderColors();
        updateSelection();
      });
      container.appendChild(button);
    });
  }

  function renderQuantities() {
    var container = $("prod-quantities");
    if (!container || !QUANTITIES) return;
    container.innerHTML = "";
    QUANTITIES.forEach(function (quantity, index) {
      var selected = index === selectedQuantity;
      var button = document.createElement("button");
      button.type = "button";
      button.className =
        "h-14 rounded-lg border-2 text-sm font-semibold transition-colors relative px-2 " +
        (selected
          ? "border-[#0086ff] bg-[#0086ff]/5 text-[#0086ff]"
          : "border-gray-300 bg-white text-foreground");
      button.innerHTML = "<span style=\"display:block\">" + quantity.name + "</span><span style=\"display:block;font-size:12px;margin-top:2px\">R$ " + String(quantity.price).replace(".", ",") + "</span>";
      button.setAttribute("aria-label", "Selecionar " + quantity.name + " por R$ " + quantity.price);
      button.setAttribute("aria-pressed", String(selected));
      button.addEventListener("click", function () {
        selectedQuantity = index;
        applySelectionImage();
        renderQuantities();
        updateSelection();
      });
      container.appendChild(button);
    });
  }

  function describeSelection() {
    var parts = [];
    if (QUANTITIES) parts.push("Quantidade: " + QUANTITIES[selectedQuantity].name);
    if (SIZES.length) parts.push(SIZE_LABEL + ": " + SIZES[selectedSize]);
    if (COLORS) parts.push("Cor: " + COLORS[selectedColor].name);
    return parts.join(" | ");
  }

  function applyVariant() {
    if (!VARIANTS || !VARIANTS[selectedSize]) return;
    var variant = VARIANTS[selectedSize];

    if (variant.image) {
      var foundIndex = IMAGES.indexOf(variant.image);
      if (foundIndex !== -1 && foundIndex !== imageIndex) {
        imageIndex = foundIndex;
        renderGallery();
      }
    }

    if (variant.price) {
      var price = String(variant.price).replace(".", ",").split(",");
      var reais = $("prod-price-reais");
      var centavos = $("prod-price-centavos");
      var fixed = $("prod-price-fixed");
      if (reais) reais.textContent = price[0];
      if (centavos) centavos.textContent = "," + (price[1] || "00").padEnd(2, "0");
      if (fixed) fixed.textContent = "R$" + price[0] + "," + (price[1] || "00").padEnd(2, "0");
    }

    if (variant.originalPrice) {
      var originalPrice = $("prod-original-price");
      if (originalPrice) originalPrice.textContent = "R$ " + String(variant.originalPrice).replace(".", ",");
    }

    var stockWarning = $("prod-stock-warning");
    if (stockWarning) {
      if (variant.stock) {
        stockWarning.textContent = "Últimas " + variant.stock + " unidades deste kit";
        stockWarning.style.display = "flex";
      } else {
        stockWarning.style.display = "none";
      }
    }
  }

  function applyQuantity() {
    if (!QUANTITIES || !QUANTITIES[selectedQuantity]) return;
    var quantity = QUANTITIES[selectedQuantity];
    var price = String(quantity.price).replace(".", ",").split(",");
    var reais = $("prod-price-reais");
    var centavos = $("prod-price-centavos");
    var fixed = $("prod-price-fixed");
    if (reais) reais.textContent = price[0];
    if (centavos) centavos.textContent = "," + (price[1] || "00").padEnd(2, "0");
    if (fixed) fixed.textContent = "R$" + price[0] + "," + (price[1] || "00").padEnd(2, "0");
    var originalPrice = $("prod-original-price");
    if (originalPrice && quantity.originalPrice) {
      originalPrice.textContent = "R$ " + String(quantity.originalPrice).replace(".", ",");
    }

    var count = quantity.count || parseInt(quantity.name, 10);
    if (count) {
      var title = "Kit " + count + " Camisetas Masculinas Polo Wear";
      var productTitle = $("prod-title");
      var item = $("prod-desc-item");
      var complete = $("prod-desc-count");
      var packageCount = $("prod-package-count");
      var specProduct = $("prod-spec-product");
      var mainImage = $("prod-main-image");
      if (productTitle) productTitle.textContent = title;
      if (item) item.textContent = "Kit com " + count + " Camisetas Masculinas Polo Wear.";
      if (complete) complete.textContent = count + " camisetas masculinas";
      if (packageCount) packageCount.textContent = count + "x Camisetas Masculinas Polo Wear";
      if (specProduct) specProduct.textContent = "Kit " + count + " Camisetas Masculinas";
      if (mainImage) mainImage.alt = title;
      document.title = title + " | Magalu";
      var metaDescription = document.querySelector('meta[name="description"]');
      if (metaDescription) metaDescription.content = "Kit com " + count + " camisetas masculinas Polo Wear, confortáveis e versáteis para o dia a dia.";
    }
  }

  function updateSelection() {
    applyVariant();
    applyQuantity();
    syncFixedOriginalPrice();
    var sel = $("prod-selection");
    if (sel) sel.textContent = describeSelection();
    updateCheckoutLinks();
  }

  function syncFixedOriginalPrice() {
    var originalPrice = $("prod-original-price") || document.querySelector(".line-through");
    var buyButton = $("prod-buy-fixed");
    if (!originalPrice || !buyButton) return;

    var priceBox = buyButton.previousElementSibling;
    if (!priceBox) return;

    var existingPrice = $("prod-original-price-fixed");
    if (!existingPrice && priceBox.querySelector(".line-through")) return;

    if (!existingPrice) {
      existingPrice = document.createElement("p");
      existingPrice.id = "prod-original-price-fixed";
      existingPrice.style.cssText = "margin:0 0 2px;color:#6b7280;font-size:12px;line-height:16px;text-decoration:line-through";
      priceBox.insertBefore(existingPrice, priceBox.firstChild);
    }
    existingPrice.textContent = originalPrice.textContent.trim();
  }

  function buildCheckoutUrl() {
    var description = describeSelection();
    var quantity = QUANTITIES && QUANTITIES[selectedQuantity];
    var quantityCheckout = quantity && Array.isArray(quantity.checkouts)
      ? quantity.checkouts[selectedColor]
      : null;
    var colorCheckout = COLORS && COLORS[selectedColor]
      ? COLORS[selectedColor].checkout
      : null;
    var checkoutBase = quantityCheckout
      || colorCheckout
      || (VARIANTS && VARIANTS[selectedSize] && VARIANTS[selectedSize].checkout
        ? VARIANTS[selectedSize].checkout
        : CHECKOUT);
    try {
      var checkout = new URL(checkoutBase);
      new URLSearchParams(window.location.search).forEach(function (value, key) {
        if (!/^utm_/i.test(key)) checkout.searchParams.set(key, value);
      });
      // Repassa também UTMs recuperadas quando a URL atual não as contém.
      Object.keys(utms).forEach(function (key) {
        checkout.searchParams.set(key, utms[key]);
      });
      if (QUANTITIES) checkout.searchParams.set("quantidade", QUANTITIES[selectedQuantity].name);
      if (SIZES.length) checkout.searchParams.set(SIZE_PARAM, SIZES[selectedSize]);
      if (COLORS) checkout.searchParams.set("cor", COLORS[selectedColor].name);
      if (description) checkout.searchParams.set("desc", description);
      return checkout.toString();
    } catch (error) {
      var qs = [];
      if (QUANTITIES) qs.push("quantidade=" + encodeURIComponent(QUANTITIES[selectedQuantity].name));
      if (SIZES.length) qs.push(SIZE_PARAM + "=" + encodeURIComponent(SIZES[selectedSize]));
      if (COLORS) qs.push("cor=" + encodeURIComponent(COLORS[selectedColor].name));
      if (description) qs.push("desc=" + encodeURIComponent(description));
      return qs.length ? checkoutBase + "?" + qs.join("&") : checkoutBase;
    }
  }

  function updateCheckoutLinks() {
    var url = buildCheckoutUrl();
    ["prod-buy-main", "prod-buy-fixed"].forEach(function (id) {
      var link = $(id);
      if (link) link.href = url;
    });
  }

  window.prodToggleSpecs = function () {
    var specs = $("prod-specs");
    var button = $("prod-specs-button");
    var isOpen = specs.style.display !== "none";
    specs.style.display = isOpen ? "none" : "block";
    button.textContent = isOpen ? "Ver ficha técnica completa" : "Ver menos";
  };

  window.prodOpenExit = function () {
    if (/\/obrigado(\/|$|\?)/.test(document.referrer)) {
      window.location.href = "/obrigado";
      return;
    }
    $("prod-exit-modal").style.display = "flex";
  };
  window.prodCloseExit = function () {
    $("prod-exit-modal").style.display = "none";
  };

  window.prodOpenPhoto = function (src) {
    $("prod-photo-modal-img").src = src;
    $("prod-photo-modal").style.display = "flex";
  };
  window.prodClosePhoto = function () {
    $("prod-photo-modal").style.display = "none";
  };

  window.prodToggleVideo = function () {
    var video = $("prod-video");
    if (!video) return;
    if (video.paused) video.play();
    else video.pause();
  };

  function initVideoPlayer() {
    var video = $("prod-video");
    var overlay = $("prod-video-overlay");
    var icon = $("prod-video-icon");
    if (!video || !overlay || !icon) return;

    var pauseIcon = '<path d="M6 5h4v14H6zM14 5h4v14h-4z"></path>';
    var playIcon = '<path d="M8 5v14l11-7z"></path>';

    video.addEventListener("play", function () {
      overlay.classList.add("bg-transparent");
      overlay.classList.remove("bg-black/20");
      icon.parentElement.classList.add("opacity-0");
      icon.innerHTML = pauseIcon;
    });
    video.addEventListener("pause", function () {
      overlay.classList.remove("bg-transparent");
      overlay.classList.add("bg-black/20");
      icon.parentElement.classList.remove("opacity-0");
      icon.innerHTML = playIcon;
    });
  }

  function init() {
    var gallery = $("prod-gallery");
    if (gallery) {
      gallery.addEventListener(
        "touchstart",
        function (event) {
          touchStartX = event.touches[0].clientX;
        },
        { passive: true }
      );
      gallery.addEventListener("touchend", function (event) {
        var distance = event.changedTouches[0].clientX - touchStartX;
        if (Math.abs(distance) > 40) {
          moveGallery(distance < 0 ? 1 : -1);
        }
      });
    }

    // PT-BR: botões simples nas bordas da imagem para navegar no carrossel.
    var previousButton = $("prod-gallery-prev");
    var nextButton = $("prod-gallery-next");
    if (previousButton) {
      previousButton.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        moveGallery(-1);
      });
    }
    if (nextButton) {
      nextButton.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        moveGallery(1);
      });
    }

    // PT-BR: botão de coração da foto do produto. Ao clicar, fica vermelho como curtida.
    var favoriteButton = $("prod-favorite-button");
    if (favoriteButton) {
      favoriteButton.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        var liked = favoriteButton.classList.toggle("prod-liked");
        favoriteButton.setAttribute("aria-pressed", String(liked));
        favoriteButton.setAttribute("aria-label", liked ? "Remover dos favoritos" : "Adicionar aos favoritos");
      });
    }

    renderGallery();
    renderSizes();
    renderColors();
    renderQuantities();
    updateSelection();
    initVideoPlayer();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
